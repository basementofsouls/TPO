const ClassificationLevel  = {
    UNCLASSIFIED: 'Unclassified',
    CONFIDENTIAL: 'Confidential',
    SECRET: 'Secret',
    TOP_SECRET: 'Top_secret'
};

module.exports =  ClassificationLevel;
